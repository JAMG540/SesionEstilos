function asigna(param)
{
    var inputAsignado=document.getElementById('invalidar');
    var parametro=param;
    
    inputAsignado.value=parametro;
}
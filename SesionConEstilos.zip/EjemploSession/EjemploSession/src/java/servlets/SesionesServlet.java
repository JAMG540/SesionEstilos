/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class SesionesServlet extends HttpServlet {
   
  public void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

         String nombre;
         String apellido;
        
      //recuperamos los datos del formulario
          nombre = request.getParameter("NOMBRE");
          apellido = request.getParameter("APELLIDO");
         
      HttpSession sesion = request.getSession();
      sesion.setAttribute("claveSesion", nombre + apellido);

       response.setContentType("text/html");
      //Mostramos los  valores en el cliente
      PrintWriter out = response.getWriter();
      
      
       
       
        
      out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
                out.println("<script src='js/funciones.js' type='text/javascript'></script>");
                out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
                out.println("<link href='css/materialize.min.css' rel='stylesheet' type='text/css'/>");
                out.println("<script src='js/jquery-3.0.0.min.js' type='text/javascript'></script>");
                out.println("<script src='js/materialize.min.js' type='text/javascript'></script>");
                out.println("<link href='http://fonts.googleapis.com/icon?family=Material+Icons' rel='stylesheet'>");
                
            out.println("</head>");
            out.println("<body>");
                    out.println("<div class='lime accent-1'><a href=\"/EjemploSession/catalogo.jsp\"> Link al catalogo del carrito</a></div>");
                    out.println("<br/><br/>");
                    out.println("<div class='green accent-3'>ID de la sesi&oacute;n: " + sesion.getId()+"</div>");
            out.println("</body>");
            out.println("</html>");
     
  
    }
  
  protected void doGet(HttpServletRequest request, HttpServletResponse response)    throws ServletException, java.io.IOException 
  {


  }

  @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
   

}

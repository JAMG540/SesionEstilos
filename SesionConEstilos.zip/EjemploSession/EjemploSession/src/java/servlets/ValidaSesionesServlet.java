/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class ValidaSesionesServlet extends HttpServlet {
   
    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

      response.setContentType("text/html");
      HttpSession sesion = request.getSession();
      String titulo = null;

      //Pedimos el atributo, y verificamos si existe
      String claveSesion = (String) sesion.getAttribute("claveSesion");

      if(claveSesion.equals("emmanueloropeza")){
        titulo = "llave correcta continua la sesion";
      }
      else
      {
        titulo = "llave incorrecta inicie nuevamente sesion";
      }


      //Mostramos los  valores en el cliente
      
    PrintWriter out = response.getWriter();
      
  out.println("<html>");

            
    out.println("<head>");
        out.println("<title>"); 
        out.println("</title>");
        
        out.println("<script src='js/funciones.js' type='text/javascript'></script>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<link href='css/materialize.min.css' rel='stylesheet' type='text/css'/>");
        out.println("<script src='js/jquery-3.0.0.min.js' type='text/javascript'></script>");
        out.println("<script src='js/materialize.min.js' type='text/javascript'></script>");
        out.println("<link href='http://fonts.googleapis.com/icon?family=Material+Icons' rel='stylesheet'>");
       
    out.println("</head>");


    
    out.println("<body>");


    out.print("<div class='row'>");
      
      
      
      
      out.println("<div class='col s12'>¿Continua la Sesion y es valida?: " + titulo+ "</div>");
      out.println("<br>");
      out.println("<div class='col s6'>ID de la sesi&oacute;n JSESSIONID: " + sesion.getId()+"</div>");
   
      out.println("</div>");
      
      out.println("<br/><br/><br/><br/><br/>");
      
      out.println("<form method='post' action='invalidarSesion.jsp'>");
      
        out.println("<input type='hidden'  id='invalidar' name='invalidar'/>");
        out.println("<input type='submit' value='Cerrar sesión' id='cerrar' onclick='asigna('1')'/>");
    out.println("</form>");
        
       out.println("<br/><br/><br/><br/><br/>");
    
   out.println("</body>");
out.println("</html>");


  
    }
    
    

}
